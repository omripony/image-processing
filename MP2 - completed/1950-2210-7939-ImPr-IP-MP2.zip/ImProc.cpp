
#include <conio.h> // for _getch

// the following is needed for cin and cout instead of printf
#include <iostream>
#include <fstream>
using namespace std;  // explain someday

// The following is needed for math calculations
#include <math.h>
#define _USE_MATH_DEFINES 
#include <cmath> 

#include <time.h>  // for spead measurements

#include "ImProcInPlainC.h" // needed for those who wants to program in Plain C
#include "PrimeFFTn.h"      // for basic FFT operations

//#define FILTER_SIZE_1 20
//#define FILTER_SIZE_2 2
//#define FILTER_SIZE_3 1

#define myMAXCOLORS 256

#define FILTER_HALF_WIDTH 2
#define FILTER_HALF_HEIGHT 2
#define FILTER_HALF_SIZE 12

unsigned char byteOriginal[VGA_HEIGHT][VGA_WIDTH];  //This is an array to store the original image data. SIZE_256 is a constant defined in the header

tFloat floatRe[VGA_HEIGHT][VGA_WIDTH];  //This stores the real part of an image in the frequency domain.
tFloat floatIm[VGA_HEIGHT][VGA_WIDTH];  // This stores the imaginary part of an image in the frequency domain.
tFloat floatFilter[VGA_HEIGHT][VGA_WIDTH];
unsigned char GrayImage1[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];


//The following kernels are the tested kernels in MP2.4 









double kernel_3x3_option2_High_Boost_Filter[FILTER_HALF_HEIGHT + 1][FILTER_HALF_HEIGHT + 1] =
{
   {-0.25, -0.25, -0.25},
   {-0.25, 2.5, -0.25},
   {-0.25, -0.25, -0.25}
};

double kernel_3x3_option3_Unsharp_Masking_Filter[FILTER_HALF_HEIGHT + 1][FILTER_HALF_HEIGHT + 1] =
{
   {-1, -1, -1},
   {-1, 9, -1},
   {-1, -1, -1}
};











double kernel_5x5_option2_High_Boost_Filter[2 * FILTER_HALF_HEIGHT + 1][2 * FILTER_HALF_HEIGHT + 1] =
{
   {-1, -1, -1, -1, -1},
   {-1, -1, -1, -1, -1},
   {-1, -1, 24, -1, -1},
   {-1, -1, -1, -1, -1},
   {-1, -1, -1, -1, -1}
};





















double kernel_7x7_option2_High_Boost_Filter[2 * FILTER_HALF_HEIGHT + 3][2 * FILTER_HALF_HEIGHT + 3] =
{
   {-1, -1, -1, -1, -1, -1, -1},
   {-1, -1, -1, -1, -1, -1, -1},
   {-1, -1, -1, -1, -1, -1, -1},
   {-1, -1, -1, 49, -1, -1, -1},
   {-1, -1, -1, -1, -1, -1, -1},
   {-1, -1, -1, -1, -1, -1, -1},
   {-1, -1, -1, -1, -1, -1, -1}
};












unsigned char temp_dest[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];


//DoFiltationByConvolution is a given function by samuel - page 5 in filtration by convolution lecture
void DoFiltationByConvolution(unsigned char src[][NUMBER_OF_COLUMNS], unsigned char dest[][NUMBER_OF_COLUMNS],
							  double* filter, int filter_size)
{
	// Calculate half-width and half-height dynamically based on the filter size
	int filter_half_size = filter_size / 2;

	// Perform convolution
	for (int row = filter_half_size; row < NUMBER_OF_ROWS - filter_half_size; row++)
	{
		for (int column = filter_half_size; column < NUMBER_OF_COLUMNS - filter_half_size; column++)
		{
			double summa = 0;
			for (int y = -filter_half_size; y <= filter_half_size; y++)
			{
				for (int x = -filter_half_size; x <= filter_half_size; x++)
				{
					// Perform convolution with the unsharp masking kernel
					summa += filter[(y + filter_half_size) * filter_size + (x + filter_half_size)] * src[row + y][column + x];
				}
			}

			// Clip values to the 0-255 range
			summa = std::min(255.0, std::max(0.0, summa));

			// Write the result into the destination image
			dest[row][column] = static_cast<unsigned char>(summa);
		}
	}
}


//convert is a given function by samuel - page 59 in FFT part 1 lecture
void Convert(tFloat floatImage[][NUMBER_OF_COLUMNS], unsigned char byteOriginal[][NUMBER_OF_COLUMNS], tFloat minVal, tFloat maxVal)
{
	tFloat* ptrToFloatImage = floatImage[0];
	tFloat c, b, temp;
	if (minVal == maxVal)
	{
		c = 1; b = 0;
	}
	else
	{
		c = 255.0 / (maxVal - minVal);
		b = -c * minVal;
	}

	unsigned char* ptrToByteImage = byteOriginal[0];
	ptrToFloatImage = floatImage[0];

	for (int pixel = 0; pixel < NUMBER_OF_COLUMNS * NUMBER_OF_ROWS; pixel++)
	{
		temp = c * (*ptrToFloatImage++) + b;
		if (temp < 0)    temp = 0;
		if (temp > 255)  temp = 255;
		*ptrToByteImage++ = (unsigned char)((int)temp);
	}
}


//OptimalConvert is a given function by samuel - page 60 in FFT part 1 lecture
void OptimalConvert(tFloat floatImage[][NUMBER_OF_COLUMNS],	unsigned char byteOriginal[][NUMBER_OF_COLUMNS])
{
	tFloat* ptrToFloatImage = floatImage[0];
	tFloat MinVal, MaxVal, temp;
	// Find MinMax
	MinVal = *ptrToFloatImage;
	MaxVal = MinVal;

	for (int pixel = 0; pixel < NUMBER_OF_COLUMNS * NUMBER_OF_ROWS; pixel++)
	{
		temp = *ptrToFloatImage++;
		if (MinVal > temp) MinVal = temp;
		if (MaxVal < temp) MaxVal = temp;
	}
	Convert(floatImage, byteOriginal, MinVal, MaxVal);
}


//DoFFT is a given function by samuel - page 61 in FFT part 1 lecture
void DoFFT(tFloat imageRe[][NUMBER_OF_COLUMNS],	tFloat imageIm[][NUMBER_OF_COLUMNS], int exponentSign,int normalizationScalingType)
{

	tFloat* ptrToRe = imageRe[0];
	tFloat* ptrToIm = imageIm[0];

	tInteger arrayOfDimensions[2];
	arrayOfDimensions[0] = NUMBER_OF_COLUMNS;
	arrayOfDimensions[1] = NUMBER_OF_ROWS;

	PrimeFFTn(2,
		arrayOfDimensions,
		ptrToRe,
		ptrToIm,
		exponentSign,
		normalizationScalingType);
}


//ShiftHalfSize is a given function by samuel - page 62 in FFT part 1 lecture
void ShiftHalfSize(tFloat floatImage[][NUMBER_OF_COLUMNS])
{
	tFloat* floatImage_ptr= floatImage[0];
	for (int row = 0; row < NUMBER_OF_ROWS; row++)
	{
		for (int column = 0; column < NUMBER_OF_COLUMNS; column += 2)
		{
			floatImage[row][column] *= -1;
		}
	}

	for (int row = 0; row < NUMBER_OF_ROWS; row += 2)
	{
		for (int column = 0; column < NUMBER_OF_COLUMNS; column++)
		{
			floatImage[row][column] *= -1;
		}
	}
}


//DoFiltrationInFD is a given function by samuel - page 63 in FFT part 1 lecture
void DoFiltrationInFD(tFloat floatRe[][NUMBER_OF_COLUMNS],tFloat floatIm[][NUMBER_OF_COLUMNS],tFloat floatFilter[][NUMBER_OF_COLUMNS])
{
	tFloat* ptrToRe = floatRe[0];
	tFloat* ptrToIm = floatIm[0];
	tFloat* ptrToFilter = floatFilter[0];

	for (int pixel = 0; pixel < NUMBER_OF_ROWS * NUMBER_OF_COLUMNS; pixel++)
	{
		*ptrToRe++ *= *ptrToFilter;
		*ptrToIm++ *= *ptrToFilter++;
	}

}


void CreateGreyGaussian(unsigned char(*image)[NUMBER_OF_COLUMNS], double SigmaX, double SigmaY) {
	int midy = NUMBER_OF_ROWS / 2;
	int midx = NUMBER_OF_COLUMNS / 2;

	for (int row = 0; row < NUMBER_OF_ROWS; row++) {
		for (int column = 0; column < NUMBER_OF_COLUMNS; column++) {
			double xa = column - midx;
			xa /= SigmaX;
			double ya = row - midy;
			ya /= SigmaY;

			double answer = 255.0 * (exp(-xa * xa - ya * ya));

			image[row][column] = (unsigned char)(unsigned)(answer);
		}
	}
}


void DoGaussianFiltration(unsigned char* src, double* filter, int filter_size) //filteration using convolution - x direction and then y direction
{
	int half_size = (filter_size - 1) / 2;
	double summa;

	memset(temp_dest, 0, sizeof(temp_dest));  

// x direction
	for (int row = 0; row < NUMBER_OF_ROWS; row++) {
		for (int column = half_size; column < NUMBER_OF_COLUMNS - half_size; column++) {
			summa = 0;
			for (int x = -half_size; x <= half_size; x++) {
				summa += filter[half_size + x] * (double)*(src + row * NUMBER_OF_COLUMNS + (column + x));
			}
			if (summa < 0) summa = 0;
			if (summa > 255) summa = 255;
			*(temp_dest[0] + row * NUMBER_OF_COLUMNS + column) = (unsigned char)summa;
		}
	}

	// Clear Source !!!
	for (int i = 0; i < NUMBER_OF_ROWS * NUMBER_OF_COLUMNS; i++) {
		src[i] = 0;
	}

	// y direction
	for (int row = half_size; row < NUMBER_OF_ROWS - half_size; row++) {
		for (int column = 0; column < NUMBER_OF_COLUMNS; column++) {
			summa = 0;
			for (int y = -half_size; y <= half_size; y++) {
				summa += filter[half_size + y] * *(temp_dest[0] + (row + y) * NUMBER_OF_COLUMNS + column);}			
			if (summa < 0) summa = 0;
			if (summa > 255) summa = 255;
			*(src + row * NUMBER_OF_COLUMNS + column) = (unsigned char)summa;
		}
	}
}


//work() is the a general function that includes all the steps that necessary for conducting FFT and filtering in FD in the blurring process
void Work(unsigned char ProccesIMG[][NUMBER_OF_COLUMNS], int filter_size)
{
	cout << "FFT Filtration in nearly Plain C" << endl;

	// Step 1: Input image processing - FFT in preparation for the filtration process in DoFiltrationInFD
	for (int i = 0; i < NUMBER_OF_ROWS; i++)
	{
		for (int j = 0; j < NUMBER_OF_COLUMNS; j++)
		{
			floatRe[i][j] = ProccesIMG[i][j];
			floatIm[i][j] = 0;  // Ensure imaginary part is initialized to 0
		}
	}

	// Step 2: Apply FFT preprocessing (centering)
	ShiftHalfSize(floatRe);
	ShiftHalfSize(floatIm);

	// Step 3: Perform FFT to convert the image to the frequency domain
	DoFFT(floatRe, floatIm, FORWARD_FFT, NORMALIZE_BY_SQRT);

	// Step 4: Prepare the Gaussian filter
	// Modify this line to make filter_size impact the Gaussian filter
	CreateGreyGaussian(GrayImage1, filter_size / 10.0, filter_size / 10.0); // Make filter_size affect sigma
	StoreGrayImageAsGrayBmpFile(GrayImage1, "GreyGaussianFilter.bmp");

	// Convert the GrayImage1 to floatFilter (as it's likely in 8-bit unsigned char format) -- very important!!
	for (int i = 0; i < NUMBER_OF_ROWS; i++)
	{
		for (int j = 0; j < NUMBER_OF_COLUMNS; j++)
		{
			floatFilter[i][j] = (tFloat)GrayImage1[i][j] / 255.0;  // Normalize to 0-1 range
		}
	}

	// Apply the Gaussian filter in the frequency domain
	DoFiltrationInFD(floatRe, floatIm, floatFilter);

	// Step 5: Perform inverse FFT to return to the spatial domain
	DoFFT(floatRe, floatIm, REVERSE_FFT, NORMALIZE_BY_SQRT);
	ShiftHalfSize(floatRe);
	ShiftHalfSize(floatIm);

	// Debug: Save the final result after inverse FFT and shifting
	OptimalConvert(floatRe, byteOriginal);

	// Step 6: Copy the result back to ProccesIMG
	for (int i = 0; i < NUMBER_OF_ROWS; i++)
	{
		for (int j = 0; j < NUMBER_OF_COLUMNS; j++)
		{
			ProccesIMG[i][j] = byteOriginal[i][j];
		}
	}
}


void CreateLowPassFilter(tFloat(*floatFilter)[NUMBER_OF_COLUMNS], int cutoff, int order)
{
	int centerX = NUMBER_OF_COLUMNS / 2;
	int centerY = NUMBER_OF_ROWS / 2;

	// Loop to compute the low-pass filter
	for (int row = 0; row < NUMBER_OF_ROWS; row++)
	{
		for (int col = 0; col < NUMBER_OF_COLUMNS; col++)
		{
			double distance = sqrt(pow(row - centerY, 2) + pow(col - centerX, 2));
			floatFilter[row][col] = 1.0 / (1.0 + pow(distance / cutoff, 2 * order));
		}
	}
}


void CreateHighFrequencyEnhancingFilter(tFloat(*floatFilter)[NUMBER_OF_COLUMNS], int cutoff, int order, float boost_factor)
{
	// First, create the LPF
	CreateLowPassFilter(floatFilter, cutoff, order);

	// Then, compute the HFEF
	for (int row = 0; row < NUMBER_OF_ROWS; row++)
	{
		for (int col = 0; col < NUMBER_OF_COLUMNS; col++)
		{
			floatFilter[row][col] = (1.0f + boost_factor) - boost_factor * floatFilter[row][col];
		}
	}
}


void WorkHFEF(unsigned char ProccesIMG[][NUMBER_OF_COLUMNS],int cutoff,int order, float boost_factor)
{
	cout << "FFT Filtration with High Frequency Enhancing Filter (HFEF)" << endl;

	// Step 1: Prepare the image for FFT
	for (int i = 0; i < NUMBER_OF_ROWS; i++)
	{
		for (int j = 0; j < NUMBER_OF_COLUMNS; j++)
		{
			floatRe[i][j] = ProccesIMG[i][j];
			floatIm[i][j] = 0;  // Ensure imaginary part is initialized to 0
		}
	}

	// Step 2: Apply centering to the image
	ShiftHalfSize(floatRe);
	ShiftHalfSize(floatIm);

	// Step 3: Perform forward FFT on the input image for being able to filter it using HPEF in FD
	DoFFT(floatRe, floatIm, FORWARD_FFT, NORMALIZE_BY_SQRT);

	//Step 4: create a high enhancing frequencies filter  

	CreateHighFrequencyEnhancingFilter(floatFilter, cutoff, order, boost_factor);

	// Visualize the HFEF
	Convert(floatFilter, byteOriginal, 1.0f, 1.0f + boost_factor);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "HFEF.bmp");

	// Step 5: Apply the HFEF in the frequency domain
	DoFiltrationInFD(floatRe, floatIm, floatFilter);

	// Step 6: Perform inverse FFT on the filtered image in FD
	DoFFT(floatRe, floatIm, REVERSE_FFT, NORMALIZE_BY_SQRT);
	ShiftHalfSize(floatRe);
	ShiftHalfSize(floatIm);

	// Step 7: Convert and store the final result
	OptimalConvert(floatRe, byteOriginal);

	// Step 8: Copy the result back to ProccesIMG
	for (int i = 0; i < NUMBER_OF_ROWS; i++)
	{
		for (int j = 0; j < NUMBER_OF_COLUMNS; j++)
		{
			ProccesIMG[i][j] = byteOriginal[i][j];
		}
	}
}


// Declare Gray Image
unsigned char ProccesIMG1[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];  //ProccesIMG1 are the results of the blurring FFT of Tim1.bmp and then enhancing
unsigned char ProccesIMG2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];  //ProccesIMG2 are the results of the blurring FFT of Tim2.bmp and then enhancing

unsigned char src1[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];       // src1-result of the blurring convolution between 5x5 filter & Tim1
unsigned char src2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];      // src2-result of the blurring convolution between 5x5 filter & Tim2
unsigned char src3[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];	   // src3-result of the blurring convolution between 7x7 filter & Tim1
unsigned char src4[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];    // src4-result of the blurring convolution between 7x7 filter & Tim2

unsigned char dst13_option2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];     // dest13-result of the restore convolution between 3x3 kernel & src1
unsigned char dst15_option2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];    // dest15-result of the restore convolution between 5x5 kernel & src1
unsigned char dst17_option2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];    // dest17-result of the restore convolution between 7x7 kernel & src1

unsigned char dst33_option2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];     // dest33-result of the restore convolution between 3x3 kernel & src3
unsigned char dst35_option2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];    // dest35-result of the restore convolution between 5x5 kernel & src3
unsigned char dst37_option2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];    // dest37-result of the restore convolution between 7x7 kernel & src3

unsigned char dst23_option3[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];     // dest23-result of the restore convolution between 3x3 kernel & src2
unsigned char dst25_option2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];    // dest15-result of the restore convolution between 5x5 kernel & src2
unsigned char dst27_option2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];    // dest27-result of the restore convolution between 5x5 kernel & src2

unsigned char dst43_option3[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];     // dest43-result of the restore convolution between 3x3 kernel & src4
unsigned char dst45_option2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];    // dest45-result of the restore convolution between 5x5 kernel & src4
unsigned char dst47_option2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];    // dest47-result of the restore convolution between 7x7 kernel & src4


void main()
{
	//part 2 of the task - "By using reworked 2D 5x5 and 7x7 filters BLUR Image Tim1.bmp by using convolution with Fast Gaussian 1D Filters"
	cout << "Gaussian filtration for blurring the input Tim1.bmp and Tim2.bmp images" << endl;

	// Apply a 5x5 Gaussian filter
	const int FILTER_HALF_SIZE_5 = 2;
	double offset = 0.23;
	const int FILTER_SIZE_5 = 2 * FILTER_HALF_SIZE_5 + 1;
	double filter_5[FILTER_SIZE_5] = { 7 / 273 + offset, 26 / 273 + offset, 41 / 273 + offset, 26 / 273 + offset, 7 / 273 + offset };  

	LoadGrayImageFromTrueColorBmpFile(src1, "Tim1.bmp");  // Load the image
	DoGaussianFiltration(&src1[0][0], filter_5, FILTER_SIZE_5);  // Perform the filtration
	StoreGrayImageAsGrayBmpFile(src1, "Tim1LPF5c.bmp");  // Save the blurred image with 5x5 filter

	// Apply a 7x7 Gaussian filter
	const int FILTER_HALF_SIZE_7 = 3;
	const int FILTER_SIZE_7 = 2 * FILTER_HALF_SIZE_7 + 1;
	double offset2 = 0.16;
	double filter_7[FILTER_SIZE_7] = { 2 / 1003 + offset2, 22 / 1003 + offset2, 97 / 1003 + offset2, 159 / 1003 + offset2, 97 / 1003 + offset2,
									22 / 1003 + offset2, 2 / 1003 + offset2 };  

	LoadGrayImageFromTrueColorBmpFile(src3, "Tim1.bmp");  // Reload the original image
	DoGaussianFiltration(&src3[0][0], filter_7, FILTER_SIZE_7);  // Perform the filtration
	StoreGrayImageAsGrayBmpFile(src3, "Tim1LPF7c.bmp");  // Save the blurred image with 7x7 filter

	
	//********* part 4 of the task - try to enhance/restore the blurred images using convolution in TD *************

	DoFiltationByConvolution(src1, dst13_option2, &kernel_3x3_option2_High_Boost_Filter[0][0], 3);
	StoreGrayImageAsGrayBmpFile(dst13_option2, "Tim1LPF5CHFEF1C.bmp");

	//-------------------------------------------------------------------------//
	DoFiltationByConvolution(src1, dst15_option2, &kernel_5x5_option2_High_Boost_Filter[0][0], 5);
	StoreGrayImageAsGrayBmpFile(dst15_option2, "Tim1LPF5CHFEF2C.bmp");

	//-------------------------------------------------------------------------//
	DoFiltationByConvolution(src1, dst17_option2, &kernel_7x7_option2_High_Boost_Filter[0][0], 7);
	StoreGrayImageAsGrayBmpFile(dst17_option2, "Tim1LPF5CHFEF3C.bmp");


	DoFiltationByConvolution(src3, dst33_option2, &kernel_3x3_option2_High_Boost_Filter[0][0], 3);
	StoreGrayImageAsGrayBmpFile(dst33_option2, "Tim1LPF7CHFEF1C.bmp");

	//-------------------------------------------------------------------------//
	DoFiltationByConvolution(src3, dst35_option2, &kernel_5x5_option2_High_Boost_Filter[0][0], 5);
	StoreGrayImageAsGrayBmpFile(dst35_option2, "Tim1LPF7CHFEF2C.bmp");

	//-------------------------------------------------------------------------//
	DoFiltationByConvolution(src3, dst37_option2, &kernel_7x7_option2_High_Boost_Filter[0][0], 7);
	StoreGrayImageAsGrayBmpFile(dst37_option2, "Tim1LPF7CHFEF3C.bmp");

	///// now we will examine the same for Tim2.bmp : 
	LoadGrayImageFromGrayBmpFile(src4, "Tim2.bmp");  // Load the image
	DoGaussianFiltration(&src4[0][0], filter_7, FILTER_SIZE_7);  // Perform the filtration
	StoreGrayImageAsGrayBmpFile(src4, "Tim2LPF7c.bmp");  // Save the blurred image with 7x7 filter

	LoadGrayImageFromGrayBmpFile(src2, "Tim2.bmp");  // Load the image
	DoGaussianFiltration(&src2[0][0], filter_5, FILTER_SIZE_5);  // Perform the filtration
	StoreGrayImageAsGrayBmpFile(src2, "Tim2LPF5c.bmp");  // Save the blurred image with 5x5 filter

	//-------------------------------------------------------------------------//

	DoFiltationByConvolution(src2, dst23_option3, &kernel_3x3_option3_Unsharp_Masking_Filter[0][0], 3);
	StoreGrayImageAsGrayBmpFile(dst23_option3, "Tim2LPF5CHFEF1C.bmp");

	//-------------------------------------------------------------------------//
	DoFiltationByConvolution(src2, dst25_option2, &kernel_5x5_option2_High_Boost_Filter[0][0], 5);
	StoreGrayImageAsGrayBmpFile(dst25_option2, "Tim2LPF5CHFEF2C.bmp");

	//-------------------------------------------------------------------------//
	DoFiltationByConvolution(src2, dst27_option2, &kernel_7x7_option2_High_Boost_Filter[0][0], 7);
	StoreGrayImageAsGrayBmpFile(dst27_option2, "Tim2LPF5CHFEF3C.bmp");

	//-------------------------------------------------------------------------//
	
	DoFiltationByConvolution(src4, dst43_option3, &kernel_3x3_option3_Unsharp_Masking_Filter[0][0], 3);
	StoreGrayImageAsGrayBmpFile(dst43_option3, "Tim2LPF7CHFEF1C.bmp");

	//-------------------------------------------------------------------------//
	DoFiltationByConvolution(src4, dst45_option2, &kernel_5x5_option2_High_Boost_Filter[0][0], 5);
	StoreGrayImageAsGrayBmpFile(dst45_option2, "Tim2LPF7CHFEF2C.bmp");

	//-------------------------------------------------------------------------//
	DoFiltationByConvolution(src4, dst47_option2, &kernel_7x7_option2_High_Boost_Filter[0][0], 7);
	StoreGrayImageAsGrayBmpFile(dst47_option2, "Tim2LPF7CHFEF3C.bmp");


	//********* part 3 of the task - "Blur test Images by using FFT using Gaussian Filter in FD. " *************

	// Load and process the Tim1.bmp image
	LoadGrayImageFromTrueColorBmpFile(ProccesIMG1, "Tim1.bmp");
	
	/// FFT filtration to blur using gaussian filter  
	Work(ProccesIMG1, 375);
	StoreGrayImageAsGrayBmpFile(ProccesIMG1, "Tim1LPFF.bmp");
	// Step 4: Create the HFEF
	int cutoff_tim1 = 500;         // Adjust as needed
	int order_tim1 = 1;            // Adjust as needed
	float boost_factor_tim1 = 150.0f;
	/// FFT filtration using HPEF to restore (enhance) the blurred image - section 5 
	WorkHFEF(ProccesIMG1, cutoff_tim1, order_tim1, boost_factor_tim1);


	StoreGrayImageAsGrayBmpFile(ProccesIMG1, "Tim1LPFFHFEFf.bmp");

	////**************************************************************
	////***** repeat the steps before on Tim2.bmp given image **********

	// Load and process the Tim2.bmp image
	LoadGrayImageFromGrayBmpFile(ProccesIMG2, "Tim2.bmp");

	/// FFT filtration using gaussian filter
	Work(ProccesIMG2, 500);
	StoreGrayImageAsGrayBmpFile(ProccesIMG2,"Tim2LPFF.bmp");
	// Step 4: Create the HFEF
	int cutoff_tim2 = 500;         // Adjust as needed
	int order_tim2 = 1;            // Adjust as needed
	float boost_factor_tim2 = 150.0f;
	//// FFT filtration using HPF to restore (enhance) the blurred image - section 5 
	WorkHFEF(ProccesIMG2, cutoff_tim2, order_tim2, boost_factor_tim2);
	StoreGrayImageAsGrayBmpFile(ProccesIMG2, "Tim2LPFFHFEFf.bmp");

	cout << "Press any key to exit" << endl;
	
}
