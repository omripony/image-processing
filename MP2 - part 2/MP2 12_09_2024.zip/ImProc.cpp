
#include <conio.h> // for _getch

// the following is needed for cin and cout instead of printf
#include <iostream>
#include <fstream>
using namespace std;  // explain someday

// The following is needed for math calculations
#include <math.h>
#define _USE_MATH_DEFINES 
#include <cmath> 

#include <time.h>  // for spead measurements

#include "ImProcInPlainC.h" // needed for those who wants to program in Plain C
#include "PrimeFFTn.h"      // for basic FFT operations

#define FILTER_SIZE_1 20
#define FILTER_SIZE_2 2
#define FILTER_SIZE_3 1

#define myMAXCOLORS 256

#define FILTER_HALF_WIDTH 2
#define FILTER_HALF_HEIGHT 2
#define FILTER_HALF_SIZE 12

unsigned char byteOriginal[VGA_HEIGHT][VGA_WIDTH];  //This is an array to store the original image data. SIZE_256 is a constant defined in the header

tFloat floatRe[VGA_HEIGHT][VGA_WIDTH];  //This stores the real part of an image in the frequency domain.
tFloat floatIm[VGA_HEIGHT][VGA_WIDTH];  // This stores the imaginary part of an image in the frequency domain.
tFloat floatFilter[VGA_HEIGHT][VGA_WIDTH];
unsigned char GrayImage1[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];


//These are 2 filter kernels used for convolution operations. The values inside these matrices represent the filter coefficients.
//these kernels are 5x5 HPF kernels - can be found in the web

double kernel_1[2 * FILTER_HALF_HEIGHT +1][2 * FILTER_HALF_HEIGHT + 1] = 
{
	 
	{-5,   -5,   -10,   -5,   -5},
	{-5,   -20,  10,   -20,   -5},
	{-10,   10,  700,   10,  -10},
	{-5,   -20,  10,   -20,   -5},
	{-5,   -5,   -10,   -5,   -5}
};


//double kernel_1[2 * FILTER_HALF_HEIGHT + 1][2 * FILTER_HALF_HEIGHT + 1] = {
//	{ 0,  0,   0,  0,  0},
//	{ 0, -2,  -4, -2,  0},
//	{ 0, -4,  16, -4,  0},
//	{ 0, -2,  -4, -2,  0},
//	{ 0,  0,   0,  0,  0}
//};






double kernel_2[ FILTER_HALF_HEIGHT + 1][2 * FILTER_HALF_HEIGHT + 1] = {
	 {  0, -1,  0},
    { -1,  4, -1},
    {  0, -1,  0}
};



double kernel_3[4 * FILTER_HALF_HEIGHT + 1][4 * FILTER_HALF_HEIGHT + 1] =
{
	

	{-1, -1, -1, -1, -1, -1, -1, -1, -1},
	{-1, -1, -1, -1, -1, -1, -1, -1, -1},
	{-1, -1,  1,  2,  2,  2,  1, -1, -1},
	{-1, -1,  2,  3,  4,  3,  2, -1, -1},
	{-1, -1,  2,  4, 50,  4,  2, -1, -1},  // Reduced center
	{-1, -1,  2,  3,  4,  3,  2, -1, -1},
	{-1, -1,  1,  2,  2,  2,  1, -1, -1},
	{-1, -1, -1, -1, -1, -1, -1, -1, -1},
	{-1, -1, -1, -1, -1, -1, -1, -1, -1}
};





double kernel_4[2 * FILTER_HALF_HEIGHT + 1][2 * FILTER_HALF_HEIGHT + 1] = {
	{ 0, -1, -1, -1,  0},
	{-1,  2,  2,  2, -1},
	{-1,  2,  300,  2, -1},
	{-1,  2,  2,  2, -1},
	{ 0, -1, -1, -1,  0}
};


unsigned char temp_dest[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];


//DoFiltationByConvolution is a given function by samuel - page 5 in filtration by convolution lecture
#include <cstdlib> // for malloc and free

#include <algorithm>  // For std::min and std::max

void DoFiltationByConvolution(unsigned char src[][NUMBER_OF_COLUMNS], unsigned char dest[][NUMBER_OF_COLUMNS],
	double* filter, int filter_size)
{
	// Calculate half-width and half-height dynamically based on the filter size
	int filter_half_size = filter_size / 2;

	// Perform convolution
	for (int row = filter_half_size; row < NUMBER_OF_ROWS - filter_half_size; row++)
	{
		for (int column = filter_half_size; column < NUMBER_OF_COLUMNS - filter_half_size; column++)
		{
			double summa = 0;
			for (int y = -filter_half_size; y <= filter_half_size; y++)
			{
				for (int x = -filter_half_size; x <= filter_half_size; x++)
				{
					// Perform convolution with the unsharp masking kernel
					summa += filter[(y + filter_half_size) * filter_size + (x + filter_half_size)] * src[row + y][column + x];
				}
			}

			// Clip values to the 0-255 range
			summa = std::min(255.0, std::max(0.0, summa));

			// Write the result into the destination image
			dest[row][column] = static_cast<unsigned char>(summa);
		}
	}
}





//convert is a given function by samuel - page 59 in FFT part 1 lecture
void Convert(tFloat floatImage[][NUMBER_OF_COLUMNS], unsigned char byteOriginal[][NUMBER_OF_COLUMNS], tFloat minVal, tFloat maxVal)
{
	tFloat* ptrToFloatImage = floatImage[0];
	tFloat c, b, temp;
	if (minVal == maxVal)
	{
		c = 1; b = 0;
	}
	else
	{
		c = 255.0 / (maxVal - minVal);
		b = -c * minVal;
	}

	unsigned char* ptrToByteImage = byteOriginal[0];
	ptrToFloatImage = floatImage[0];

	for (int pixel = 0; pixel < NUMBER_OF_COLUMNS * NUMBER_OF_ROWS; pixel++)
	{
		temp = c * (*ptrToFloatImage++) + b;
		if (temp < 0)    temp = 0;
		if (temp > 255)  temp = 255;
		*ptrToByteImage++ = (unsigned char)((int)temp);
	}
}


//OptimalConvert is a given function by samuel - page 60 in FFT part 1 lecture
void OptimalConvert(tFloat floatImage[][NUMBER_OF_COLUMNS],	unsigned char byteOriginal[][NUMBER_OF_COLUMNS])
{
	tFloat* ptrToFloatImage = floatImage[0];
	tFloat MinVal, MaxVal, temp;
	// Find MinMax
	MinVal = *ptrToFloatImage;
	MaxVal = MinVal;

	for (int pixel = 0; pixel < NUMBER_OF_COLUMNS * NUMBER_OF_ROWS; pixel++)
	{
		temp = *ptrToFloatImage++;
		if (MinVal > temp) MinVal = temp;
		if (MaxVal < temp) MaxVal = temp;
	}
	Convert(floatImage, byteOriginal, MinVal, MaxVal);
}


//DoFFT is a given function by samuel - page 61 in FFT part 1 lecture
void DoFFT(tFloat imageRe[][NUMBER_OF_COLUMNS],	tFloat imageIm[][NUMBER_OF_COLUMNS], int exponentSign,int normalizationScalingType)
{

	tFloat* ptrToRe = imageRe[0];
	tFloat* ptrToIm = imageIm[0];

	tInteger arrayOfDimensions[2];
	arrayOfDimensions[0] = NUMBER_OF_COLUMNS;
	arrayOfDimensions[1] = NUMBER_OF_ROWS;

	PrimeFFTn(2,
		arrayOfDimensions,
		ptrToRe,
		ptrToIm,
		exponentSign,
		normalizationScalingType);
}


//ShiftHalfSize is a given function by samuel - page 62 in FFT part 1 lecture
void ShiftHalfSize(tFloat floatImage[][NUMBER_OF_COLUMNS])
{
	tFloat* floatImage_ptr= floatImage[0];
	for (int row = 0; row < NUMBER_OF_ROWS; row++)
	{
		for (int column = 0; column < NUMBER_OF_COLUMNS; column += 2)
		{
			floatImage[row][column] *= -1;
		}
	}

	for (int row = 0; row < NUMBER_OF_ROWS; row += 2)
	{
		for (int column = 0; column < NUMBER_OF_COLUMNS; column++)
		{
			floatImage[row][column] *= -1;
		}
	}
}


//CreateRectangle is a given function by samuel - page 64 in FFT part 1 lecture
void CreateRectangle(tFloat* floatImage, int halfHeight, int halfWidth, tFloat centralValue, tFloat peripheryValue)
{
	// Fill the entire image with the peripheryValue
	for (int row = 0; row < NUMBER_OF_ROWS; row++)
	{
		for (int column = 0; column < NUMBER_OF_COLUMNS; column++)
		{
			*(floatImage + row * NUMBER_OF_COLUMNS + column) = peripheryValue;
		}
	}

	// Set the central rectangle to centralValue
	for (int row = NUMBER_OF_ROWS / 2 - halfHeight; row < NUMBER_OF_ROWS / 2 + halfHeight; row++)
	{
		for (int column = NUMBER_OF_COLUMNS / 2 - halfWidth; column < NUMBER_OF_COLUMNS / 2 + halfWidth; column++)
		{
			*(floatImage + row * NUMBER_OF_COLUMNS + column) = centralValue;
		}
	}
}



//DoFiltrationInFD is a given function by samuel - page 63 in FFT part 1 lecture
void DoFiltrationInFD(tFloat floatRe[][NUMBER_OF_COLUMNS],tFloat floatIm[][NUMBER_OF_COLUMNS],tFloat floatFilter[][NUMBER_OF_COLUMNS])
{
	tFloat* ptrToRe = floatRe[0];
	tFloat* ptrToIm = floatIm[0];
	tFloat* ptrToFilter = floatFilter[0];

	for (int pixel = 0; pixel < NUMBER_OF_ROWS * NUMBER_OF_COLUMNS; pixel++)
	{
		*ptrToRe++ *= *ptrToFilter;
		*ptrToIm++ *= *ptrToFilter++;
	}

}


void PrepareGaussianFilter(double* filter, int filter_size, double sigma)
{
	int half_size = (filter_size - 1) / 2;
	double summa = 0;

	for (int i = 0; i < filter_size; i++)
	{
		double temp = (double)(i - half_size) / sigma;
		temp = exp(-temp * temp);
		*(filter + i) = temp;  // Use pointer arithmetic instead of array indexing
		summa += temp;
	}

	for (int i = 0; i < filter_size; i++)
	{
		*(filter + i) /= summa;  // Normalize the filter using pointer arithmetic
	}
}



void CreateGreyGaussian(unsigned char(*image)[NUMBER_OF_COLUMNS], double SigmaX, double SigmaY) {
	int midy = NUMBER_OF_ROWS / 2;
	int midx = NUMBER_OF_COLUMNS / 2;

	for (int row = 0; row < NUMBER_OF_ROWS; row++) {
		for (int column = 0; column < NUMBER_OF_COLUMNS; column++) {
			double xa = column - midx;
			xa /= SigmaX;
			double ya = row - midy;
			ya /= SigmaY;

			double answer = 255.0 * (exp(-xa * xa - ya * ya));

			image[row][column] = (unsigned char)(unsigned)(answer);
		}
	}
}
void HPF(unsigned char(*image)[NUMBER_OF_COLUMNS], double SigmaX, double SigmaY)
{
	int midy = NUMBER_OF_ROWS / 2;
	int midx = NUMBER_OF_COLUMNS / 2;

	for (int row = 0; row < NUMBER_OF_ROWS; row++) {
		for (int column = 0; column < NUMBER_OF_COLUMNS; column++) {
			double xa = column - midx;
			xa /= SigmaX;
			double ya = row - midy;
			ya /= SigmaY;

			// Calculate the Gaussian-based HPF response
			double answer = 255.0 * (1 - exp(-xa * xa - ya * ya));

			// Clip the value to avoid underflow/overflow
			if (answer < 0) answer = 0;
			if (answer > 255) answer = 255;

			image[row][column] = (unsigned char)(unsigned)(answer);
		}
	}
}



void CreateHFEF(tFloat HFEF[][NUMBER_OF_COLUMNS], double alpha)
{
	int centerX = NUMBER_OF_COLUMNS / 2;
	int centerY = NUMBER_OF_ROWS / 2;

	for (int row = 0; row < NUMBER_OF_ROWS; row++)
	{
		for (int col = 0; col < NUMBER_OF_COLUMNS; col++)
		{
			double distance = sqrt(pow(row - centerY, 2) + pow(col - centerX, 2));
			HFEF[row][col] = 1 + alpha * distance;
		}
	}
}


void DoGaussianFiltration(unsigned char* src, double* filter, int filter_size) //filteration using convolution - x direction and then y direction
{
	int half_size = (filter_size - 1) / 2;
	double summa;

	memset(temp_dest, 0, sizeof(temp_dest));  

// x direction
	for (int row = 0; row < NUMBER_OF_ROWS; row++) {
		for (int column = half_size; column < NUMBER_OF_COLUMNS - half_size; column++) {
			summa = 0;
			for (int x = -half_size; x <= half_size; x++) {
				summa += filter[half_size + x] * (double)*(src + row * NUMBER_OF_COLUMNS + (column + x));
			}
			if (summa < 0) summa = 0;
			if (summa > 255) summa = 255;
			*(temp_dest[0] + row * NUMBER_OF_COLUMNS + column) = (unsigned char)summa;
		}
	}

	// Clear Source !!!
	for (int i = 0; i < NUMBER_OF_ROWS * NUMBER_OF_COLUMNS; i++) {
		src[i] = 0;
	}

	// y direction
	for (int row = half_size; row < NUMBER_OF_ROWS - half_size; row++) {
		for (int column = 0; column < NUMBER_OF_COLUMNS; column++) {
			summa = 0;
			for (int y = -half_size; y <= half_size; y++) {
				summa += filter[half_size + y] * *(temp_dest[0] + (row + y) * NUMBER_OF_COLUMNS + column);}			
			if (summa < 0) summa = 0;
			if (summa > 255) summa = 255;
			*(src + row * NUMBER_OF_COLUMNS + column) = (unsigned char)summa;
		}
	}
}


void CreateHighPassFilter(tFloat(*floatFilter)[NUMBER_OF_COLUMNS], int cutoff, int order)
{
	int centerX = NUMBER_OF_COLUMNS / 2;
	int centerY = NUMBER_OF_ROWS / 2;

	// Loop to compute the high-pass filter
	for (int row = 0; row < NUMBER_OF_ROWS; row++)
	{
		for (int col = 0; col < NUMBER_OF_COLUMNS; col++)
		{
			double distance = sqrt(pow(row - centerY, 2) + pow(col - centerX, 2));
			floatFilter[row][col] = 1.0 / (1.0 + pow((double)cutoff / (distance + 1e-10), 2 * order));
		}
	}

	// Invert the filter values to correctly visualize the HPF
	for (int row = 0; row < NUMBER_OF_ROWS; row++)
	{
		for (int col = 0; col < NUMBER_OF_COLUMNS; col++)
		{
			floatFilter[row][col] = 1.0 - floatFilter[row][col];
		}
	}
}





//version 4 of work() function - i understood that the problem in the first part of the work() function - the FFT of the given image.
//so a change to see if the FFT of the given image is as neccecery 

void Work(unsigned char ProccesIMG[][NUMBER_OF_COLUMNS], int filter_size)
{
	cout << "FFT Filtration in nearly Plain C" << endl;

	// Step 1: Input image processing - FFT in preparation for the filtration process in DoFiltrationInFD
	for (int i = 0; i < NUMBER_OF_ROWS; i++)
	{
		for (int j = 0; j < NUMBER_OF_COLUMNS; j++)
		{
			floatRe[i][j] = ProccesIMG[i][j];
			floatIm[i][j] = 0;  // Ensure imaginary part is initialized to 0
		}
	}

	Convert(floatRe, byteOriginal, 0, 255);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Tim1_Initial.bmp");

	// Step 2: Apply FFT preprocessing (centering)
	ShiftHalfSize(floatRe);
	ShiftHalfSize(floatIm);

	Convert(floatRe, byteOriginal, 0, 255);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Tim1_After_Shift.bmp");

	// Step 3: Perform FFT to convert the image to the frequency domain
	DoFFT(floatRe, floatIm, FORWARD_FFT, NORMALIZE_BY_SQRT);

	Convert(floatRe, byteOriginal, 0, 50);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Tim1_FFT_Before_Filtering.bmp");

	// Step 4: Prepare the Gaussian filter
	// Modify this line to make filter_size impact the Gaussian filter
	CreateGreyGaussian(GrayImage1, filter_size / 10.0, filter_size / 10.0); // Make filter_size affect sigma
	StoreGrayImageAsGrayBmpFile(GrayImage1, "GreyGaussianFilter.bmp");

	// Convert the GrayImage1 to floatFilter (as it's likely in 8-bit unsigned char format) -- very important!!
	for (int i = 0; i < NUMBER_OF_ROWS; i++)
	{
		for (int j = 0; j < NUMBER_OF_COLUMNS; j++)
		{
			floatFilter[i][j] = (tFloat)GrayImage1[i][j] / 255.0;  // Normalize to 0-1 range
		}
	}

	// Apply the Gaussian filter in the frequency domain
	DoFiltrationInFD(floatRe, floatIm, floatFilter);

	// Debug: Save the filtered frequency domain image before inverse FFT
	Convert(floatRe, byteOriginal, 0, 50);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Filtered_Image_in_FD_before_IFFT.bmp");

	// Step 5: Perform inverse FFT to return to the spatial domain
	DoFFT(floatRe, floatIm, REVERSE_FFT, NORMALIZE_BY_SQRT);
	ShiftHalfSize(floatRe);
	ShiftHalfSize(floatIm);

	// Debug: Save the final result after inverse FFT and shifting
	OptimalConvert(floatRe, byteOriginal);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Tim1_Final_Result.bmp");

	// Step 6: Copy the result back to ProccesIMG
	for (int i = 0; i < NUMBER_OF_ROWS; i++)
	{
		for (int j = 0; j < NUMBER_OF_COLUMNS; j++)
		{
			ProccesIMG[i][j] = byteOriginal[i][j];
		}
	}
}



void WorkHPEF1(unsigned char ProccesIMG[][NUMBER_OF_COLUMNS], int filter_size)
{
	cout << "FFT Filtration in nearly Plain C" << endl;

	// Step 1: Input image processing - FFT in preparation for the filtration process
	for (int i = 0; i < NUMBER_OF_ROWS; i++)
	{
		for (int j = 0; j < NUMBER_OF_COLUMNS; j++)
		{
			floatRe[i][j] = ProccesIMG[i][j];
			floatIm[i][j] = 0;  // Ensure imaginary part is initialized to 0
		}
	}

	Convert(floatRe, byteOriginal, 0, 255);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Tim2_Initial.bmp");

	// Step 2: Apply FFT preprocessing (centering)
	ShiftHalfSize(floatRe);
	ShiftHalfSize(floatIm);

	Convert(floatRe, byteOriginal, 0, 255);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Tim2_After_Shift.bmp");

	// Step 3: Perform FFT to convert the image to the frequency domain
	DoFFT(floatRe, floatIm, FORWARD_FFT, NORMALIZE_BY_SQRT);

	Convert(floatRe, byteOriginal, 0, 50);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Tim2_FFT_Before_Filtering.bmp");

	// Step 4: Create the High Frequency Enhancing Filter (HFEF)
	int cutoff = 80; // Use the best cutoff frequency from the last row
	int order = 8;   // Use the best order from the last row
	CreateHighPassFilter(floatFilter, cutoff, order);
	OptimalConvert(floatFilter, byteOriginal);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Filter.bmp");

	// Step 5: Apply the HFEF in the frequency domain
	DoFiltrationInFD(floatRe, floatIm, floatFilter);

	// Debug: Save the filtered frequency domain image before inverse FFT
	Convert(floatRe, byteOriginal, 0, 50);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Filtered_Image_in_FD_before_IFFT.bmp");

	// Step 6: Perform inverse FFT to return to the spatial domain
	DoFFT(floatRe, floatIm, REVERSE_FFT, NORMALIZE_BY_SQRT);
	ShiftHalfSize(floatRe);
	ShiftHalfSize(floatIm);

	// Debug: Save the final result after inverse FFT and shifting
	OptimalConvert(floatRe, byteOriginal);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Tim2_Final_Result_With_HFEF.bmp");

	// Step 7: Copy the result back to ProccesIMG
	for (int i = 0; i < NUMBER_OF_ROWS; i++)
	{
		for (int j = 0; j < NUMBER_OF_COLUMNS; j++)
		{
			ProccesIMG[i][j] = byteOriginal[i][j];
		}
	}
}


void WorkHPEF2(unsigned char ProccesIMG[][NUMBER_OF_COLUMNS], int filter_size)
{
	cout << "FFT Filtration in nearly Plain C" << endl;

	// Step 1: Input image processing - FFT in preparation for the filtration process
	for (int i = 0; i < NUMBER_OF_ROWS; i++)
	{
		for (int j = 0; j < NUMBER_OF_COLUMNS; j++)
		{
			floatRe[i][j] = ProccesIMG[i][j];
			floatIm[i][j] = 0;  // Ensure imaginary part is initialized to 0
		}
	}

	Convert(floatRe, byteOriginal, 0, 255);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Tim1_Initial.bmp");

	// Step 2: Apply FFT preprocessing (centering)
	ShiftHalfSize(floatRe);
	ShiftHalfSize(floatIm);

	Convert(floatRe, byteOriginal, 0, 255);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Tim1_After_Shift.bmp");

	// Step 3: Perform FFT to convert the image to the frequency domain
	DoFFT(floatRe, floatIm, FORWARD_FFT, NORMALIZE_BY_SQRT);

	Convert(floatRe, byteOriginal, 0, 50);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Tim1_FFT_Before_Filtering.bmp");

	// Step 4: Create the High Frequency Enhancing Filter (HFEF)
	CreateHFEF(floatFilter, 1);  // Adjust the alpha value to control the strength of enhancement

	// Debug: Save the HFEF for inspection
	Convert(floatFilter, byteOriginal, 0, 255);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "HFEF.bmp");

	// Step 5: Apply the HFEF in the frequency domain
	DoFiltrationInFD(floatRe, floatIm, floatFilter);

	// Debug: Save the filtered frequency domain image before inverse FFT
	Convert(floatRe, byteOriginal, 0, 50);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Filtered_Image_in_FD_before_IFFT.bmp");

	// Step 6: Perform inverse FFT to return to the spatial domain
	DoFFT(floatRe, floatIm, REVERSE_FFT, NORMALIZE_BY_SQRT);
	ShiftHalfSize(floatRe);
	ShiftHalfSize(floatIm);

	// Debug: Save the final result after inverse FFT and shifting
	OptimalConvert(floatRe, byteOriginal);
	StoreGrayImageAsGrayBmpFile(byteOriginal, "Tim1_Final_Result_With_HFEF.bmp");

	// Step 7: Copy the result back to ProccesIMG
	for (int i = 0; i < NUMBER_OF_ROWS; i++)
	{
		for (int j = 0; j < NUMBER_OF_COLUMNS; j++)
		{
			ProccesIMG[i][j] = byteOriginal[i][j];
		}
	}
}


// Declare Gray Image
unsigned char ProccesIMG1[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];
unsigned char ProccesIMG2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];
unsigned char dst[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];
unsigned char src1[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];
unsigned char src2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];
unsigned char src3[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];
unsigned char src4[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];
void main()
{
	//part 1 of the task - "By using reworked 2D 5x5 and 7x7 filters BLUR Image Tim1.bmp by using convolution with Fast Gaussian 1D Filters"
	cout << "Gaussian Filter" << endl;

	//***** option 1 for part 1 - using the PrepareGaussianFilter function ******
	// Apply a 5x5 Gaussian filter
	const int FILTER_HALF_SIZE_5 = 2;
	double offset = 0.24;
	const int FILTER_SIZE_5 = 2 * FILTER_HALF_SIZE_5 + 1;
	double filter_5[FILTER_SIZE_5] = { 7 / 273 + offset, 26 / 273 + offset, 41 / 273 + offset, 26 / 273 + offset, 7 / 273 + offset };  // Use the provided filter

	LoadGrayImageFromTrueColorBmpFile(src1, "Tim1.bmp");  // Load the image
	DoGaussianFiltration(&src1[0][0], filter_5, FILTER_SIZE_5);  // Perform the filtration
	StoreGrayImageAsGrayBmpFile(src1, "Tim1LPF5c.bmp");  // Save the blurred image with 5x5 filter

	LoadGrayImageFromGrayBmpFile(src2, "Tim2.bmp");  // Load the image
	DoGaussianFiltration(&src2[0][0], filter_5, FILTER_SIZE_5);  // Perform the filtration
	StoreGrayImageAsGrayBmpFile(src2, "Tim2LPF5c.bmp");  // Save the blurred image with 5x5 filter

	// Apply a 7x7 Gaussian filter
	const int FILTER_HALF_SIZE_7 = 3;
	const int FILTER_SIZE_7 = 2 * FILTER_HALF_SIZE_7 + 1;
	double offset2 = 0.16;
	double filter_7[FILTER_SIZE_7] = { 2 / 1003 + offset2, 22 / 1003 + offset2, 97 / 1003 + offset2, 159 / 1003 + offset2, 97 / 1003 + offset2, 22 / 1003 + offset2, 2 / 1003 + offset2 };  // Use the provided filter

	LoadGrayImageFromTrueColorBmpFile(src3, "Tim1.bmp");  // Reload the original image
	DoGaussianFiltration(&src3[0][0], filter_7, FILTER_SIZE_7);  // Perform the filtration
	StoreGrayImageAsGrayBmpFile(src3, "Tim1LPF7c.bmp");  // Save the blurred image with 7x7 filter

	LoadGrayImageFromGrayBmpFile(src4, "Tim2.bmp");  // Load the image
	DoGaussianFiltration(&src4[0][0], filter_7, FILTER_SIZE_7);  // Perform the filtration
	StoreGrayImageAsGrayBmpFile(src4, "Tim2LPF7c.bmp");  // Save the blurred image with 7x7 filter

	//********* part 2 of the task - "Blur test Image by using FFT and �restore it� *************

	// Load and process the Tim1.bmp image
	LoadGrayImageFromTrueColorBmpFile(ProccesIMG1, "Tim1.bmp");
	StoreGrayImageAsGrayBmpFile(ProccesIMG1, "Tim1_gray.bmp");  //**for debugging

	/// FFT filtration to blur using gaussian filter - section 3 
	Work(ProccesIMG1, 600);
	StoreGrayImageAsGrayBmpFile(ProccesIMG1, "Tim1LPFF.bmp");
	
	
	
	// convolution filtration using HPF with different kernels - here Applying kernel_3 on src1 - section 4 
	DoFiltationByConvolution(src1, dst, &kernel_2[0][0], 3);
	StoreGrayImageAsGrayBmpFile(dst, "Tim1LPF5cHFEF3c.bmp");  // Tim1 blurred by gaussian in size 5 restored by kernel_3

	// convolution filtration using HPF with different kernels - here Applying kernel_3 on src3 - section 4 
	DoFiltationByConvolution(src3, dst, &kernel_3[0][0], 9);
	StoreGrayImageAsGrayBmpFile(dst, "Tim1LPF7cHFEF3c.bmp");  // Tim1 blurred by gaussian in size 7 restored by kernel_3
	//------------------------------------------------------------//
	// convolution filtration using HPF with different kernels - here Applying kernel_1 on src1
	// - section 4 
	DoFiltationByConvolution(src1, dst, &kernel_1[0][0], 5);
	StoreGrayImageAsGrayBmpFile(dst, "Tim1LPF5cHFEF1checking.bmp");  // Tim1 blurred by gaussian in size 5 restored by kernel_1

	// convolution filtration using HPF with different kernels - here Applying kernel_1 on src3 - section 4 
	DoFiltationByConvolution(src3, dst, &kernel_1[0][0], 5);
	StoreGrayImageAsGrayBmpFile(dst, "Tim1LPF7cHFEF1c.bmp");  // Tim1 blurred by gaussian in size 7 restored by kernel_1
	//------------------------------------------------------------//
	// convolution filtration using HPF with different kernels - here Applying kernel_4 on src1 - section 4
	DoFiltationByConvolution(src1, dst, &kernel_4[0][0], 5);
	StoreGrayImageAsGrayBmpFile(dst, "Tim1LPF5cHFEF4c.bmp");  // Tim1 blurred by gaussian in size 5 restored by kernel_4

	// convolution filtration using HPF with different kernels - here Applying kernel_4 on src3 - section 4 
	DoFiltationByConvolution(src3, dst, &kernel_4[0][0], 5);
	StoreGrayImageAsGrayBmpFile(dst, "Tim1LPF7cHFEF4c.bmp");  // Tim1 blurred by gaussian in size 7 restored by kernel_4
	//------------------------------------------------------------//
	// convolution filtration using HPF with different kernels - here Applying kernel_2 on src1 - section 4 
	DoFiltationByConvolution(src1, dst, &kernel_2[0][0], 3);
	StoreGrayImageAsGrayBmpFile(dst, "Tim1LPF5cHFEF2c.bmp");  // Tim1 blurred by gaussian in size 5 restored by kernel_2

	// convolution filtration using HPF with different kernels - here Applying kernel_2 on src3 - section 4 
	DoFiltationByConvolution(src3, dst, &kernel_2[0][0], 3);
	StoreGrayImageAsGrayBmpFile(dst, "Tim1LPF7cHFEF2c.bmp");  // Tim1 blurred by gaussian in size 7 restored by kernel_2
	//------------------------------------------------------------//

	
	/// FFT filtration using HPF to restore (enhance) the blurred image - section 5 
	WorkHPEF2(ProccesIMG1, 1);
	StoreGrayImageAsGrayBmpFile(ProccesIMG1, "Tim1HPEF.bmp");

	//**************************************************************
	//***** repeat the steps before on Tim2.bmp given image **********

	// Load and process the Tim2.bmp image
	LoadGrayImageFromGrayBmpFile(ProccesIMG2, "Tim2.bmp");

	/// FFT filtration using gaussian filter - section 3 
	Work(ProccesIMG2, 400);
	StoreGrayImageAsGrayBmpFile(ProccesIMG2, "Tim2LPFF.bmp");

	// convolution filtration using HPF with different kernels - here Applying kernel_1 on src2 - section 4 
	DoFiltationByConvolution(src2, dst, &kernel_1[0][0], 5);
	StoreGrayImageAsGrayBmpFile(dst, "Tim2LPF5cHFEF1c.bmp");  // Tim2 blurred by gaussian in size 5 restored by kernel_1

	// convolution filtration using HPF with different kernels - here Applying kernel_1 on src4 - section 4 
	DoFiltationByConvolution(src4, dst, &kernel_1[0][0], 5);
	StoreGrayImageAsGrayBmpFile(dst, "Tim2LPF7cHFEF1c.bmp");  // Tim2 blurred by gaussian in size 7 restored by kernel_1
	//------------------------------------------------------------//

	// convolution filtration using HPF with different kernels - here Applying kernel_2 on src2 - section 4 
	DoFiltationByConvolution(src2, dst, &kernel_2[0][0], 3);
	StoreGrayImageAsGrayBmpFile(dst, "Tim2LPF5cHFEF2c.bmp");  // Tim2 blurred by gaussian in size 5 restored by kernel_2

	// convolution filtration using HPF with different kernels - here Applying kernel_2 on src4 - section 4 
	DoFiltationByConvolution(src4, dst, &kernel_2[0][0], 3);
	StoreGrayImageAsGrayBmpFile(dst, "Tim2LPF7cHFEF2c.bmp");  // Tim2 blurred by gaussian in size 7 restored by kernel_2
	//------------------------------------------------------------//

	// convolution filtration using HPF with different kernels - here Applying kernel_3 on src2 - section 4 
	DoFiltationByConvolution(src2, dst, &kernel_3[0][0], 9);
	StoreGrayImageAsGrayBmpFile(dst, "Tim2LPF5cHFEF3c.bmp");  // Tim2 blurred by gaussian in size 5 restored by kernel_3

	// convolution filtration using HPF with different kernels - here Applying kernel_3 on src4 - section 4 
	DoFiltationByConvolution(src4, dst, &kernel_3[0][0], 9);
	StoreGrayImageAsGrayBmpFile(dst, "Tim2LPF7cHFEF3c.bmp");  // Tim2 blurred by gaussian in size 7 restored by kernel_3
	//------------------------------------------------------------//

	// convolution filtration using HPF with different kernels - here Applying kernel_4 on src2 - section 4 
	DoFiltationByConvolution(src2, dst, &kernel_4[0][0], 5);
	StoreGrayImageAsGrayBmpFile(dst, "Tim2LPF5cHFEF4c.bmp");  // Tim2 blurred by gaussian in size 5 restored by kernel_4

	// convolution filtration using HPF with different kernels - here Applying kernel_4 on src4 - section 4 
	DoFiltationByConvolution(src4, dst, &kernel_4[0][0], 5);
	StoreGrayImageAsGrayBmpFile(dst, "Tim2LPF7cHFEF4c.bmp");  // Tim2 blurred by gaussian in size 7 restored by kernel_4
	//------------------------------------------------------------//

	// FFT filtration using HPF to restore (enhance) the blurred image - section 5 
	WorkHPEF1(ProccesIMG2, 1);
	StoreGrayImageAsGrayBmpFile(ProccesIMG2, "Tim2HPEF.bmp");

	cout << "Press any key to exit" << endl;
	_getch();
}
