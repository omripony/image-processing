#include <stdio.h>    // for printf
#include <conio.h>    // for getch
#include <iostream>   // for cin, cout
#include <fstream>    // for file IO
#define _USE_MATH_DEFINES
#include <math.h> 
#include "ImProcInPlainC.h"
using namespace std;
//unsigned char img[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];

unsigned char img2[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];
int main() {
 Second_assignment();
    return 0;
}
void Second_assignment()
{
    const int numIllusion = 3;
    unsigned char grayLevels[numIllusion];
    int numberOfBlackHorizontalStrips = 20;
    for (int i = 0; i < numIllusion; i++) {
       
        grayLevels[i] = static_cast<unsigned char>((static_cast<float>(i) / numIllusion) * 255) / 4 + 127.5;

        createWhitesIllusion(img2
            , numberOfBlackHorizontalStrips, grayLevels[i]);
        char filename[30];
        sprintf(filename, "grayImage12%d.bmp", i+1);
        StoreGrayImageAsGrayBmpFile(img2, filename);

    }
}
void createWhitesIllusion(unsigned char img[][NUMBER_OF_COLUMNS], int numberOfBlackHorizontalStrips,
    unsigned char grayLevelOfGrayBars) {
    s2dPoint leftside{ 0, 0 }, rightside{ NUMBER_OF_COLUMNS - 1, NUMBER_OF_ROWS - 1 }; // Corrected coordinates
    AddGrayRectangle(img, leftside, rightside, 0, 255); // Full screen white rectangle
    int stripHeight = (rightside.gety() - leftside.gety()) / numberOfBlackHorizontalStrips;
    if (rightside.getx() < leftside.getx())
        leftside.change(rightside);
    int i = leftside.gety();
    int bound_right = rightside.gety();
    for (; i < bound_right; i += stripHeight) {
        s2dPoint p1, p2;
        int narrowStripWidth = abs(leftside.getx() - rightside.getx()) / 6;
        if ((i / stripHeight) % 2 == 0) {
            // Add black strip
           /* p1.setXY(leftside.getx(), i);
            p2.setXY(rightside.getx(), i + stripHeight);*/
            p1.setXY(leftside.getx(), i);
            p2.setXY(rightside.getx(), i + stripHeight);
            AddGrayRectangle(img, p1, p2, 0, 0);
            // Second narrow strip
            p1.setXY(4 * narrowStripWidth, i);
            p2.setXY(5 * narrowStripWidth, i + stripHeight);
            AddGrayRectangle(img, p1, p2, 0, grayLevelOfGrayBars);   
        }
        else {
            p1.setXY(narrowStripWidth, i);
            p2.setXY(2 * narrowStripWidth, i + stripHeight);
            AddGrayRectangle(img, p1, p2, 0, grayLevelOfGrayBars);
        }
    }
    StoreGrayImageAsGrayBmpFile(img, "white_illusion.bmp");
}
bool checkValidation(s2dPoint p1, s2dPoint p2, unsigned char image[][NUMBER_OF_COLUMNS]) {
    p1.validate();
    p2.validate();

    int top = min(p1.gety(), p2.gety());
    int bottom = max(p1.gety(), p2.gety());
    int left = min(p1.getx(), p2.getx());
    int right = max(p1.getx(), p2.getx());

    return !(top < 0 || bottom >= NUMBER_OF_ROWS || left < 0 || right >= NUMBER_OF_COLUMNS);
}

void AddGrayRectangle(unsigned char image[][NUMBER_OF_COLUMNS], s2dPoint A, s2dPoint B1, unsigned char transparency, unsigned char grayLevel) {
    // Ensure coordinates are within bounds
    A.validate();
    B1.validate();

    int top = min(A.gety(), B1.gety());
    int bottom = max(A.gety(), B1.gety());
    int left = min(A.getx(), B1.getx());
    int right = max(A.getx(), B1.getx());

    // Ensure top, bottom, left, right are within valid range
    top = max(0, top);
    bottom = min(NUMBER_OF_ROWS - 1, bottom);
    left = max(0, left);
    right = min(NUMBER_OF_COLUMNS - 1, right);

    

    // Fill the rectangle area with the specified gray level
    for (int row = top; row <= bottom; row++) {
        for (int col = left; col <= right; col++) {
            image[row][col] = static_cast<unsigned char>((transparency / 255.0) * image[row][col]
                + ((255 - transparency) / 255.0) * grayLevel);
        }
    }
}










