/*
  First steps in Image Processing
  Creating simple Synthetic Images
  Using BMP Library
*/


#include <stdio.h> // for printf
#include <conio.h> // for getch

#include <iostream> // for cin cout
#include <fstream>  // For file IO
using namespace std; // Explain some day 

// This needed to do Math calculations
#define _USE_MATH_DEFINES
#include <math.h>

// BMP Library
#include "ImProcInPlainC.h"

void CreateGrayRectangle(unsigned char image[][NUMBER_OF_COLUMNS])
{
	for (int row = 0; row < NUMBER_OF_ROWS; row++)
	{
		for (int column = 0; column < NUMBER_OF_COLUMNS; column++)
		{
			image[row][column] = 50;
		}
	}

	for (int row = NUMBER_OF_ROWS * 1 / 4; row < NUMBER_OF_ROWS * 3 / 4; row++)
	{
		for (int column = NUMBER_OF_COLUMNS * 1 / 4; column < NUMBER_OF_COLUMNS * 3 / 4; column++)
		{
			image[row][column] = 200;
		}
	}
}

void CreateGrayRamp(unsigned char image[][NUMBER_OF_COLUMNS])
{
	for (int row = 0; row < NUMBER_OF_ROWS; row++)
	{
		for (int column = 0; column < NUMBER_OF_COLUMNS; column++)
		{
			image[row][column] = 5*column;
		}
	}
}


void main()
{
	// Declare Gray Image
	unsigned char GrayImage[NUMBER_OF_ROWS][NUMBER_OF_COLUMNS];

	CreateGrayRectangle(GrayImage);
	StoreGrayImageAsGrayBmpFile(GrayImage, "GrayRectangle.bmp");

	CreateGrayRamp(GrayImage);
	StoreGrayImageAsGrayBmpFile(GrayImage, "GrayRamp.bmp");

	WaitForUserPressKey();
}